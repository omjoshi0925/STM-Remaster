SPIDER-MAN TOTAL MAYHEM NATIVE ARM64 — MILESTONE 3

This is a larger integrated step, not a one-feature test.

ADDS
- Combined multi-mesh BDAE 0.0.0.324 static-geometry loader.
- Original Level 1 geometry (geometry04.bdae) drawn by Metal.
- Original Spider-Man model + original PVRTC texture in the same 3D scene.
- Perspective third-person camera.
- Touch exploration controls:
  LEFT half drag: move Spider-Man across the scene.
  RIGHT half drag: orbit/tilt the camera.
- Native ARM64 only. No ARMv7 execution and no emulator runtime.

LIMITATIONS
This is not yet the full original game. Original skeletal animation, collision/navmesh,
combat, AI, scripting, audio event logic, UI flow and cinematics still need reconstruction.
The purpose of this integrated build is to establish the first controllable original-game scene.

APPLY
1. Unzip this patch in Downloads.
2. In Terminal: chmod +x SpiderMan_ARM64_Milestone3_Exploration_Patch/apply_to_existing_workbench.command
3. Run the .command file.
4. Choose the already-prepared SpiderMan_Native_ARM64_Port_Workbench folder.
5. Xcode opens. Select SpiderManTotalMayhem + physical iPhone, then Run.

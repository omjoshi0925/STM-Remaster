#!/bin/bash
set -euo pipefail
PATCH_ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ "$(uname -s)" != "Darwin" ]]; then echo "This patch is for macOS."; exit 2; fi
command -v cmake >/dev/null || { echo "CMake is required."; exit 2; }
TARGET="$(osascript -e 'POSIX path of (choose folder with prompt "Choose your prepared SpiderMan_Native_ARM64_Port_Workbench")')"
if [[ ! -f "$TARGET/NativePort/CMakeLists.txt" || ! -d "$TARGET/Assets/entities" || ! -d "$TARGET/Assets/levelnew_01" ]]; then
 echo "That is not the prepared workbench."; read -r -p "Press Return..."; exit 2
fi
cp "$PATCH_ROOT/files/NativePort/CMakeLists.txt" "$TARGET/NativePort/CMakeLists.txt"
cp "$PATCH_ROOT/files/NativePort/Sources/BDAE324.cpp" "$TARGET/NativePort/Sources/BDAE324.cpp"
cp "$PATCH_ROOT/files/NativePort/Sources/BDAE324.hpp" "$TARGET/NativePort/Sources/BDAE324.hpp"
cp "$PATCH_ROOT/files/NativePort/Sources/Renderer.mm" "$TARGET/NativePort/Sources/Renderer.mm"
rm -rf "$TARGET/build-ios"; mkdir -p "$TARGET/build-ios"; cd "$TARGET/build-ios"
cmake -G Xcode -DCMAKE_SYSTEM_NAME=iOS -DCMAKE_OSX_SYSROOT=iphoneos -DCMAKE_XCODE_ATTRIBUTE_DEVELOPMENT_TEAM=BHV8AWKA75 "$TARGET/NativePort"
open SpiderManTotalMayhemNative.xcodeproj
echo
echo "Milestone 3 applied: integrated Level 1 exploration build."
echo "In Xcode: SpiderManTotalMayhem + your iPhone -> Run."
echo "Controls: left-half drag moves Spider-Man; right-half drag rotates the camera."
read -r -p "Press Return to close..."

#include "BDAE324.hpp"
#include <fstream>
#include <cstring>
#include <algorithm>
#include <limits>

static uint16_t rd16(const std::vector<unsigned char>&b,size_t o){return o+2<=b.size()?(uint16_t)b[o]|((uint16_t)b[o+1]<<8):0;}
static uint32_t rd32(const std::vector<unsigned char>&b,size_t o){return o+4<=b.size()?(uint32_t)b[o]|((uint32_t)b[o+1]<<8)|((uint32_t)b[o+2]<<16)|((uint32_t)b[o+3]<<24):0;}
static float rdf(const std::vector<unsigned char>&b,size_t o){float v=0;if(o+4<=b.size())std::memcpy(&v,b.data()+o,4);return v;}
static bool ok(size_t o,size_t n,size_t s){return o<=s&&n<=s-o;}
static std::string strAt(const std::vector<unsigned char>&b,uint32_t o,uint32_t lo,uint32_t hi){if(o<lo||o>=hi||o>=b.size())return{};size_t e=o;while(e<b.size()&&e<hi&&b[e])++e;return std::string((const char*)b.data()+o,e-o);}
static bool bytes(const std::string&p,std::vector<unsigned char>&b,std::string&e){std::ifstream f(p,std::ios::binary);if(!f){e="open failed: "+p;return false;}b.assign(std::istreambuf_iterator<char>(f),{});if(b.size()<32||std::memcmp(b.data(),"BRES",4)){e="not BRES/BDAE";return false;}return true;}

bool LoadBDAE324(const std::string&path,BDAE324Resource&o,std::string&err){
 std::vector<unsigned char>b;if(!bytes(path,b,err))return false;o={};
 o.header.endian=rd16(b,4);o.header.versionField=rd16(b,6);o.header.headerSize=rd32(b,8);o.header.fileSize=rd32(b,12);o.header.numRelocations=rd32(b,16);o.header.relocationOffset=rd32(b,20);o.header.stringOffset=rd32(b,24);o.header.dataOffset=rd32(b,28);
 if(o.header.fileSize!=b.size()||o.header.relocationOffset+4ull*o.header.numRelocations!=o.header.stringOffset||o.header.dataOffset>b.size()){err="unexpected v324 layout";return false;}
 for(uint32_t i=0;i<o.header.numRelocations;i++)o.relocations.push_back(rd32(b,o.header.relocationOffset+4*i));
 size_t i=o.header.stringOffset;while(i+4<=o.header.dataOffset){uint32_t n=rd32(b,i);i+=4;if(!n)continue;if(!ok(i,n,o.header.dataOffset))break;std::string s((const char*)b.data()+i,n);o.strings.push_back(s);if(s.rfind("0,0,0,",0)==0)o.detectedVersion=s;i+=((n+3u)&~3u);}return true;
}

static bool appendMesh(const std::vector<unsigned char>&b,uint32_t dataOff,uint32_t strOff,size_t me,BDAE324MeshGeometry&out,bool allSubs){
 uint32_t meshData=rd32(b,me+12); if(!ok(meshData,44,b.size()))return false;
 uint32_t vc=rd32(b,meshData+4),vd=rd32(b,meshData+8),sc=rd32(b,meshData+12),st=rd32(b,meshData+16);
 if(!vc||!sc||!ok(vd,32,b.size())||!ok(st,(size_t)sc*32,b.size()))return false;
 uint32_t stride=rd32(b,vd),ac=rd32(b,vd+4),ao=rd32(b,vd+8),vdata=rd32(b,vd+28);
 if(stride<24||stride>256||ac<2||ac>32||!ok(ao,(size_t)ac*4,b.size())||!ok(vdata,(size_t)vc*stride,b.size()))return false;
 uint32_t po=rd32(b,ao),no=rd32(b,ao+4),uo=0xffffffffu;
 // In v324 position/normal are first; UV is commonly offset 24 even when extra attributes exist.
 for(uint32_t ai=2;ai<ac;ai++){uint32_t cand=rd32(b,ao+ai*4);if(cand==24){uo=24;break;}}
 if(uo==0xffffffffu){for(uint32_t ai=2;ai<ac;ai++){uint32_t cand=rd32(b,ao+ai*4);if(cand+8<=stride){uo=cand;break;}}}
 if(po+12>stride||no+12>stride||uo==0xffffffffu||uo+8>stride)return false;
 size_t base=out.vertices.size(); if(base+vc>65535)return false;
 for(uint32_t i=0;i<vc;i++){size_t v=vdata+(size_t)i*stride;BDAE324Vertex d;d.px=rdf(b,v+po);d.py=rdf(b,v+po+4);d.pz=rdf(b,v+po+8);d.nx=rdf(b,v+no);d.ny=rdf(b,v+no+4);d.nz=rdf(b,v+no+8);d.u=rdf(b,v+uo);d.v=rdf(b,v+uo+4);out.vertices.push_back(d);}
 uint32_t use=allSubs?sc:1;
 for(uint32_t k=0;k<use;k++){size_t se=st+(size_t)k*32;uint32_t ic=rd32(b,se+24),ip=rd32(b,se+28);if(!ic||!ok(ip,(size_t)ic*2,b.size()))continue;for(uint32_t j=0;j<ic;j++){uint16_t ix=rd16(b,ip+j*2);if(ix<vc)out.indices.push_back((uint16_t)(base+ix));}}
 if(out.name.empty())out.name=strAt(b,rd32(b,me),strOff,dataOff);return true;
}

static bool commonLoad(const std::string&path,BDAE324MeshGeometry&out,std::string&err,bool combine){
 std::vector<unsigned char>b;if(!bytes(path,b,err))return false;uint32_t fs=rd32(b,12),so=rd32(b,24),d=rd32(b,28);if(fs!=b.size()||d+84>b.size()){err="bad BDAE header";return false;}if(strAt(b,rd32(b,d),so,d)!="0,0,0,324"){err="unsupported BDAE";return false;}
 uint32_t tc=rd32(b,d+52),tt=rd32(b,d+56),mc=rd32(b,d+76),mt=rd32(b,d+80);if(!mc||!ok(mt,(size_t)mc*16,b.size())){err="mesh table missing";return false;}out={};if(tc&&ok(tt,20,b.size()))out.textureName=strAt(b,rd32(b,tt),so,d);
 out.bboxMin[0]=out.bboxMin[1]=out.bboxMin[2]=std::numeric_limits<float>::max();out.bboxMax[0]=out.bboxMax[1]=out.bboxMax[2]=-std::numeric_limits<float>::max();
 uint32_t n=combine?mc:1;for(uint32_t mi=0;mi<n;mi++){size_t me=mt+(size_t)mi*16;uint32_t md=rd32(b,me+12);if(ok(md,44,b.size())){for(int a=0;a<3;a++){out.bboxMin[a]=std::min(out.bboxMin[a],rdf(b,md+20+a*4));out.bboxMax[a]=std::max(out.bboxMax[a],rdf(b,md+32+a*4));}}appendMesh(b,d,so,me,out,combine);if(!combine&&!out.vertices.empty())break;}
 if(out.vertices.empty()||out.indices.empty()){err="no supported geometry";return false;}out.sourceStride=32;return true;
}
bool LoadFirstRenderableMeshBDAE324(const std::string&p,BDAE324MeshGeometry&o,std::string&e){return commonLoad(p,o,e,false);} 
bool LoadCombinedStaticGeometryBDAE324(const std::string&p,BDAE324MeshGeometry&o,std::string&e){return commonLoad(p,o,e,true);} 

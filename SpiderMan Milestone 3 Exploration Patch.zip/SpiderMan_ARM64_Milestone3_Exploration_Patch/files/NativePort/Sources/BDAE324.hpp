#pragma once
#include <cstdint>
#include <string>
#include <vector>

struct BDAE324Header {
  uint16_t endian=0, versionField=0;
  uint32_t headerSize=0,fileSize=0,numRelocations=0,relocationOffset=0,stringOffset=0,dataOffset=0;
};
struct BDAE324Vertex { float px=0,py=0,pz=0,nx=0,ny=0,nz=1,u=0,v=0; };
struct BDAE324MeshGeometry {
  std::string name,textureName;
  uint32_t sourceStride=0;
  float bboxMin[3]{0,0,0}, bboxMax[3]{0,0,0};
  std::vector<BDAE324Vertex> vertices;
  std::vector<uint16_t> indices;
};
struct BDAE324Resource {
  BDAE324Header header{};
  std::string detectedVersion;
  std::vector<uint32_t> relocations;
  std::vector<std::string> strings;
};

bool LoadBDAE324(const std::string&,BDAE324Resource&,std::string&);
bool LoadFirstRenderableMeshBDAE324(const std::string&,BDAE324MeshGeometry&,std::string&);
bool LoadCombinedStaticGeometryBDAE324(const std::string&,BDAE324MeshGeometry&,std::string&);

#import "Renderer.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#include "GameRuntime.hpp"
#include "BDAE324.hpp"
#include <memory>
#include <cmath>
#include <cstring>
#include <simd/simd.h>

struct TMU { simd_float4x4 mvp; simd_float4 tint; simd_float4 misc; };
static uint32_t rdle32(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static simd_float4x4 MIdent(){return matrix_identity_float4x4;}
static simd_float4x4 MTranslate(float x,float y,float z){simd_float4x4 m=MIdent();m.columns[3]={x,y,z,1};return m;}
static simd_float4x4 MRotZ(float a){float c=cosf(a),s=sinf(a);simd_float4x4 m=MIdent();m.columns[0]={c,s,0,0};m.columns[1]={-s,c,0,0};return m;}
static simd_float4x4 MPerspective(float fovy,float aspect,float zn,float zf){float y=1.0f/tanf(fovy*0.5f),x=y/aspect,z=zf/(zn-zf);simd_float4x4 m={};m.columns[0]={x,0,0,0};m.columns[1]={0,y,0,0};m.columns[2]={0,0,z,-1};m.columns[3]={0,0,z*zn,0};return m;}
static simd_float4x4 MLookAt(simd_float3 eye,simd_float3 target,simd_float3 up){simd_float3 z=simd_normalize(eye-target),x=simd_normalize(simd_cross(up,z)),y=simd_cross(z,x);simd_float4x4 m=MIdent();m.columns[0]={x.x,y.x,z.x,0};m.columns[1]={x.y,y.y,z.y,0};m.columns[2]={x.z,y.z,z.z,0};m.columns[3]={-simd_dot(x,eye),-simd_dot(y,eye),-simd_dot(z,eye),1};return m;}

static id<MTLTexture> Fallback(id<MTLDevice>d){MTLTextureDescriptor*q=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm width:1 height:1 mipmapped:NO];id<MTLTexture>t=[d newTextureWithDescriptor:q];uint8_t p[4]={255,255,255,255};[t replaceRegion:MTLRegionMake2D(0,0,1,1) mipmapLevel:0 withBytes:p bytesPerRow:4];return t;}
static id<MTLTexture> LoadPVRTC(id<MTLDevice>d,NSString*path){NSData*data=[NSData dataWithContentsOfFile:path];if(!data||data.length<60)return nil;const uint8_t*b=data.bytes;if(memcmp(b,"BTEXpvr",7))return nil;uint32_t hs=rdle32(b+8),w=rdle32(b+12),h=rdle32(b+16),flags=rdle32(b+24),len=rdle32(b+28),bpp=rdle32(b+32);if(hs<52||!w||!h||bpp!=4)return nil;size_t p=hs;if(p+8<=data.length&&!memcmp(b+p,"PVR!",4))p+=8;if(p+len>data.length||(flags&0xff)!=0x19)return nil;MTLPixelFormat f=(flags&0x8000)?MTLPixelFormatPVRTC_RGBA_4BPP:MTLPixelFormatPVRTC_RGB_4BPP;MTLTextureDescriptor*td=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:f width:w height:h mipmapped:NO];id<MTLTexture>t=[d newTextureWithDescriptor:td];if(t)[t replaceRegion:MTLRegionMake2D(0,0,w,h) mipmapLevel:0 withBytes:b+p bytesPerRow:0];return t;}

@interface TMRenderer(){
 id<MTLDevice>_d;id<MTLCommandQueue>_q;id<MTLRenderPipelineState>_pipe;id<MTLDepthStencilState>_depth;id<MTLSamplerState>_samp;
 id<MTLBuffer>_pv,*_pi,*_lv,*_li;NSUInteger _pic,_lic;id<MTLTexture>_ptex,*_white;
 BDAE324MeshGeometry _player,_level;std::unique_ptr<GameRuntime>_game;UILabel*_label;CFTimeInterval _last;
 float _px,_py,_pz,_yaw,_camYaw,_camPitch,_lastX,_lastY;bool _touching,_moveTouch,_playerOK,_levelOK;
}
@end
@implementation TMRenderer
-(instancetype)initWithView:(MTKView*)v statusLabel:(UILabel*)label{if((self=[super init])){
 _d=MTLCreateSystemDefaultDevice();_q=[_d newCommandQueue];_game=std::make_unique<GameRuntime>();_label=label;v.device=_d;v.colorPixelFormat=MTLPixelFormatBGRA8Unorm;v.depthStencilPixelFormat=MTLPixelFormatDepth32Float;v.preferredFramesPerSecond=60;v.delegate=self;
 NSString*src=@"#include <metal_stdlib>\nusing namespace metal;\nstruct V{packed_float3 p;packed_float3 n;float2 uv;};struct U{float4x4 mvp;float4 tint;float4 misc;};struct O{float4 p[[position]];float2 uv;float l;};vertex O vv(const device V*a[[buffer(0)]],constant U&u[[buffer(1)]],uint i[[vertex_id]]){V v=a[i];O o;o.p=u.mvp*float4(float3(v.p),1);o.uv=float2(v.uv.x,1-v.uv.y);o.l=.38+.62*max(dot(normalize(float3(v.n)),normalize(float3(-.4,-.5,.8))),0.0);return o;}fragment half4 ff(O i[[stage_in]],texture2d<half>t[[texture(0)]],sampler s[[sampler(0)]],constant U&u[[buffer(1)]]){half3 b=(u.misc.x>.5)?t.sample(s,i.uv).rgb:half3(u.tint.rgb);return half4(b*half(i.l),half(u.tint.a));}";
 NSError*er=nil;id<MTLLibrary>lib=[_d newLibraryWithSource:src options:nil error:&er];MTLRenderPipelineDescriptor*pd=[MTLRenderPipelineDescriptor new];pd.vertexFunction=[lib newFunctionWithName:@"vv"];pd.fragmentFunction=[lib newFunctionWithName:@"ff"];pd.colorAttachments[0].pixelFormat=v.colorPixelFormat;pd.depthAttachmentPixelFormat=v.depthStencilPixelFormat;_pipe=[_d newRenderPipelineStateWithDescriptor:pd error:&er];MTLDepthStencilDescriptor*dd=[MTLDepthStencilDescriptor new];dd.depthCompareFunction=MTLCompareFunctionLess;dd.depthWriteEnabled=YES;_depth=[_d newDepthStencilStateWithDescriptor:dd];MTLSamplerDescriptor*sd=[MTLSamplerDescriptor new];sd.minFilter=sd.magFilter=MTLSamplerMinMagFilterLinear;_samp=[_d newSamplerStateWithDescriptor:sd];_white=Fallback(_d);
 NSString*root=NSBundle.mainBundle.resourcePath;_game->boot(root.UTF8String);auto sm=_game->summary();std::string pe,le;
 NSString*pp=[root stringByAppendingPathComponent:@"Assets/entities/meshes_bin/spiderman_mesh.bdae"];_playerOK=LoadFirstRenderableMeshBDAE324(pp.UTF8String,_player,pe);
 NSString*lp=[root stringByAppendingPathComponent:@"Assets/levelnew_01/meshes_bin/geometry04.bdae"];_levelOK=LoadCombinedStaticGeometryBDAE324(lp.UTF8String,_level,le);
 if(_playerOK){_pv=[_d newBufferWithBytes:_player.vertices.data() length:_player.vertices.size()*sizeof(BDAE324Vertex) options:0];_pi=[_d newBufferWithBytes:_player.indices.data() length:_player.indices.size()*2 options:0];_pic=_player.indices.size();NSString*tp=[root stringByAppendingPathComponent:[NSString stringWithFormat:@"Assets/entities/textures_bin/%s",_player.textureName.c_str()]];_ptex=LoadPVRTC(_d,tp);}
 if(_levelOK){_lv=[_d newBufferWithBytes:_level.vertices.data() length:_level.vertices.size()*sizeof(BDAE324Vertex) options:0];_li=[_d newBufferWithBytes:_level.indices.data() length:_level.indices.size()*2 options:0];_lic=_level.indices.size();_px=(_level.bboxMin[0]+_level.bboxMax[0])*.5f;_py=(_level.bboxMin[1]+_level.bboxMax[1])*.5f;_pz=_level.bboxMax[2]+2.0f;}else{_px=_py=0;_pz=0;}
 _camYaw=0;_camPitch=.32f;_yaw=0;_last=CACurrentMediaTime();
 _label.text=[NSString stringWithFormat:@"Native ARM64 exploration build\nLevel 1 room geometry: %s (%zu verts / %zu tris)\nSpider-Man: %s (%zu verts / %zu tris)\nLEFT drag = move • RIGHT drag = camera",_levelOK?"loaded":"FAILED",_level.vertices.size(),_level.indices.size()/3,_playerOK?"loaded":"FAILED",_player.vertices.size(),_player.indices.size()/3];
 }return self;}
-(void)drawInMTKView:(MTKView*)v{CFTimeInterval n=CACurrentMediaTime();float dt=(float)fmin(.05,n-_last);_last=n;_game->update(dt);id<CAMetalDrawable>d=v.currentDrawable;MTLRenderPassDescriptor*r=v.currentRenderPassDescriptor;if(!d||!r)return;r.colorAttachments[0].clearColor=MTLClearColorMake(.08,.10,.14,1);r.depthAttachment.clearDepth=1;id<MTLCommandBuffer>cb=[_q commandBuffer];id<MTLRenderCommandEncoder>e=[cb renderCommandEncoderWithDescriptor:r];[e setRenderPipelineState:_pipe];[e setDepthStencilState:_depth];[e setCullMode:MTLCullModeNone];float asp=(float)v.drawableSize.width/fmaxf(1,(float)v.drawableSize.height);float dist=520,up=230;simd_float3 target={_px,_py,_pz+90};simd_float3 eye={_px-sinf(_camYaw)*dist*cosf(_camPitch),_py-cosf(_camYaw)*dist*cosf(_camPitch),_pz+up+sinf(_camPitch)*dist};simd_float4x4 vp=simd_mul(MPerspective(55*M_PI/180,asp,1,12000),MLookAt(eye,target,{0,0,1}));
 if(_levelOK){TMU u{vp,{.46,.50,.55,1},{0,0,0,0}};[e setVertexBuffer:_lv offset:0 atIndex:0];[e setVertexBytes:&u length:sizeof(u) atIndex:1];[e setFragmentTexture:_white atIndex:0];[e setFragmentSamplerState:_samp atIndex:0];[e setFragmentBytes:&u length:sizeof(u) atIndex:1];[e drawIndexedPrimitives:MTLPrimitiveTypeTriangle indexCount:_lic indexType:MTLIndexTypeUInt16 indexBuffer:_li indexBufferOffset:0];}
 if(_playerOK){simd_float4x4 model=simd_mul(MTranslate(_px,_py,_pz),MRotZ(_yaw));TMU u{simd_mul(vp,model),{1,1,1,1},{_ptex?1.0f:0.0f,0,0,0}};[e setVertexBuffer:_pv offset:0 atIndex:0];[e setVertexBytes:&u length:sizeof(u) atIndex:1];[e setFragmentTexture:(_ptex ? _ptex : _white) atIndex:0];[e setFragmentSamplerState:_samp atIndex:0];[e setFragmentBytes:&u length:sizeof(u) atIndex:1];[e drawIndexedPrimitives:MTLPrimitiveTypeTriangle indexCount:_pic indexType:MTLIndexTypeUInt16 indexBuffer:_pi indexBufferOffset:0];}
 [e endEncoding];[cb presentDrawable:d];[cb commit];}
-(void)touchBegin:(CGPoint)p{_game->touchBegin(p.x,p.y);_touching=true;_lastX=p.x;_lastY=p.y;_moveTouch=p.x<UIScreen.mainScreen.bounds.size.width*.5;}
-(void)touchMove:(CGPoint)p{_game->touchMove(p.x,p.y);float dx=p.x-_lastX,dy=p.y-_lastY;_lastX=p.x;_lastY=p.y;if(_moveTouch){float f=-dy*2.7f,s=dx*2.7f;float sy=sinf(_camYaw),cy=cosf(_camYaw);_px+=s*cy+f*sy;_py+=-s*sy+f*cy;if(fabsf(dx)+fabsf(dy)>1)_yaw=atan2f(s*cy+f*sy,-s*sy+f*cy);}else{_camYaw-=dx*.009f;_camPitch=fmaxf(-.15f,fminf(.75f,_camPitch-dy*.006f));}}
-(void)touchEnd:(CGPoint)p{_game->touchEnd(p.x,p.y);_touching=false;}
-(void)accelerometerX:(float)x y:(float)y z:(float)z{_game->accelerometer(x,y,z);}-(void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)s{}
@end
